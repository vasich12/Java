/*
 * Copyright (c) fl_3650.
 */

package ticket24;

interface MyNumber {
}
