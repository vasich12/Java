/*
 * Copyright (c) fl_3650.
 */

package ticket24;

interface IAbstractMyNumberFactory {
    MyNumber createRational();

    MyNumber createComplex();
}
