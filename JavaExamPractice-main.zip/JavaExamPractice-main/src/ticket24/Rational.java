/*
 * Copyright (c) fl_3650.
 */

package ticket24;

class Rational implements MyNumber {
}
