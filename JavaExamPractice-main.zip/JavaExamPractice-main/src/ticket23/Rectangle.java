/*
 * Copyright (c) fl_3650.
 */

package ticket23;

class Rectangle implements IShape {
}
