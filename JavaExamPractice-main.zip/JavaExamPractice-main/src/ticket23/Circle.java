/*
 * Copyright (c) fl_3650.
 */

package ticket23;

class Circle implements IShape {
}
