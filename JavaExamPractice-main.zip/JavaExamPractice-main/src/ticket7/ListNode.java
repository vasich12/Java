/*
 * Copyright (c) Eliza
 */

package ticket7;

class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
        this.val = val;
    }
}

