/*
 * Copyright (c) Eliza
 */

package ticket9;

class ListNode {
    int val;

    ListNode next;

    public ListNode(int val) {
        this.val = val;
    }
}
